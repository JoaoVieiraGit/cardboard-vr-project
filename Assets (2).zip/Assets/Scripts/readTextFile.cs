﻿using UnityEngine;
using System.Collections;
using System.IO;

public class readTextFile : MonoBehaviour
{
	public TextMesh tm;
	public string [] words;
	public string result = "";
	public int charCount;
	public int index;
	public int currentLine;


	void Start () {
		tm = (TextMesh)GameObject.Find ("NText").GetComponent<TextMesh>();

		charCount = 0;
		currentLine = 1;
		StreamReader inp_stm = new StreamReader("Texto.txt");
		
		while(!inp_stm.EndOfStream)
		{
			string inp_ln = inp_stm.ReadLine( );
			words = inp_ln.Split(' ');

			for (index = 0; index < words.Length; index++) {
				
				string word = words[index].Trim();
				
				if (index == 0) {
					result = words[0];
					tm.text = result;
				}
				
				if (index > 0 ) {
					charCount += word.Length + 1; 
					if (charCount <= 40) {
						result += " " + word;
					}
					else {
						charCount = 0;
						result += "\n " + word;
					}
					
					
					tm.text = result;
				}
			}
		}
		
		inp_stm.Close( ); 
	}
}